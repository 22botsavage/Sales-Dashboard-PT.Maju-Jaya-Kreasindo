1. Pada Transaksi Penjualan bisa ada tambahan menu Print - AutoGenerate Invoice
